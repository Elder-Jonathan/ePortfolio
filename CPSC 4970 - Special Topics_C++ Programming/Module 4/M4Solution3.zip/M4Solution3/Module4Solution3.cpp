// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 4 Solution 3

#include <iostream>

using namespace std;


int* expandArray(const int* initialArray, int sizeEntered) {

    int sizeDoubled = sizeEntered * 2;
    int* doubledArray = new int[sizeDoubled];

    for (int i = 0; i < sizeEntered; i++) {
        *(doubledArray + i) = *(initialArray + i);
    }
    for (int i = sizeEntered; i < sizeDoubled; i++) {
        *(doubledArray + i) = 0;
    }
    return doubledArray;
}

int main() {

    cout << "A simple program that doubles the size of a user defined array and prints the results." << endl;
    cout << "-------------------------------------------------------------------\n" << endl;

    int sizeEntered;

    cout << "What is the size of the initial array? ";
    cin >> sizeEntered;
    cout << endl;

    int* initialArray = new int[sizeEntered];

    for (int i = 0; i < sizeEntered; i++) {
        cout << "Enter a INT value for index " << i + 1 << ": ";
        cin >> *(initialArray + i);
    }

    int* expandedArray = expandArray(initialArray, sizeEntered);

    cout << "\nHere is the array doubled in size with the extra elements initialized: ";

    for (int i = 0; i < sizeEntered * 2; i++) {
        cout << *(expandedArray + i) << " ";
    }
    cout << endl;

    delete[] initialArray;
    delete[] expandedArray;

    return 0;
}
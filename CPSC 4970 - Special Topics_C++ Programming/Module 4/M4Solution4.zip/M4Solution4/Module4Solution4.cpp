// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 4 Solution 4

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// This will generate a dynamic 2D array in memory with random values between 100 and 500.
int** generate2DArray(int rows, int columns) {

    srand(time(0));

    int** array = new int* [rows];

    for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
        array[rowIndex] = new int[columns];
        for (int colIndex = 0; colIndex < columns; colIndex++) {
            array[rowIndex][colIndex] = rand() % 401 + 100;
        }
    }
    return array;
}

int main() {

    cout << "A simple program that will randomly populate an array with user defined rows and columns spans." << endl;
    cout << "--------------------------------------------------------------------------------\n" << endl;

    int rows, columns;

    cout << "How many rows would you like to generate: ";
    cin >> rows;

    cout << "How many columns would you like to generate: ";
    cin >> columns;

    int** generatedArray = generate2DArray(rows, columns);

    cout << "\nHere is the randomly generated array with " << rows << " rows and " << columns << " columns: " << endl;
    cout << endl;

    for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
        for (int colIndex = 0; colIndex < columns; colIndex++) {
            cout << generatedArray[rowIndex][colIndex] << "  ";
        }
        cout << endl;
    }


    for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
        delete[] generatedArray[rowIndex];
    }
    delete[] generatedArray;

    return 0;
}
// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 4 Solution 1

#include <iostream>
#include <limits>

using namespace std;

// Is used to calc avg score by taking a pointer as starting point of array.
double calcAvg(double* allScores, int size) {
    double total = 0;
    for (int i = 0; i < size; i++) {
        total = total + *(allScores + i);
    }
    return total / size;
}

int main() {

    cout << "A simple program that averages a user defined number of test scores." << endl;
    cout << "--------------------------------------------------------------\n" << endl;

    int numberOfScores;
    cout << "How many test scores would you like to enter? ";

    // Input validation for number of scores
    while (true) {
        cin >> numberOfScores;
        if (cin.fail() || numberOfScores <= 0) {
            cout << "Please enter a valid positive integer: ";
            cin.clear(); // Clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discards the invalid input.
        }
        else {
            break;
        }
    }
    cout << endl;

    // Dynamically added array while the program is running.
    double* allScores = new double[numberOfScores];

    for (int i = 0; i < numberOfScores; i++) {
        cout << "Enter a score for tester " << i + 1 << ": ";
        while (true) {
            cin >> *(allScores + i);
            if (cin.fail() || *(allScores + i) < 0) {
                cout << "Please enter a valid positive score: ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            else {
                break;
            }
        }
    }

    // This will do the actual calculation after taking all the required user input.
    double averageOfScores = calcAvg(allScores, numberOfScores);

    // Effectively the "toString" statement before the program ends.
    cout << "\nThe average of the " << numberOfScores << " entered test scores is a : " << averageOfScores << endl;

    // Deallocated the space in memory for the array.
    delete[] allScores;

    return 0;
}


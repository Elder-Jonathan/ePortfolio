// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 4 Solution 2

#include <iostream>
#include <limits>

using namespace std;

// Function to create a reversed copy of an array
int* arrayReversed(const int* array, int sizeEntered) {
    int* arrayReversed = new int[sizeEntered];
    for (int i = 0; i < sizeEntered; i++) {
        *(arrayReversed + i) = *(array + sizeEntered - 1 - i);
    }
    return arrayReversed;
}

int main() {

    cout << "A simple program that takes the size of an array and lets the user enter values for each index." << endl;
    cout << "------------------------------------------------------------------------\n" << endl;

    int sizeEntered;

    cout << "Enter the number of integer values you would like to enter for the array: ";
    while (true) {
        cin >> sizeEntered;
        if (cin.fail() || sizeEntered <= 0) {
            cout << "Please enter a valid positive integer: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        else {
            break; // Valid input
        }
    }
    cout << endl;

    int* array = new int[sizeEntered];

    for (int i = 0; i < sizeEntered; i++) {
        while (true) {
            cout << "Enter int value at index " << i + 1 << ": ";
            cin >> *(array + i);
            if (cin.fail()) {
                cout << "Please enter a valid integer value:" << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Enter int value at index " << i + 1 << ": ";
            }
            else {
                break; // Valid input
            }
        }
    }

    int* reversedArray = arrayReversed(array, sizeEntered);

    cout << "\nThe int array you entered in reverse is: ";

    for (int i = 0; i < sizeEntered; i++) {
        cout << *(reversedArray + i) << " ";
    }
    cout << endl;

    delete[] array;
    delete[] reversedArray;

    return 0;
}

// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 6

#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

int main() {

    vector<int> testScores;
    int numberOfTestesScores;
    int score;
    double testGradeAverage;

    cout << "A simple program that averages test scores" << endl;
    cout << "------------------------------------------" << endl;

    cout << "\nEnter the total number of test scores you would like to average for: ";
    cin >> numberOfTestesScores;
    cout << endl;

    for (int i = 0; i < numberOfTestesScores; ++i) {

        cout << "Enter score for test " << i + 1 << ": ";
        cin >> score;
        testScores.push_back(score);
    }

    int total = accumulate(testScores.begin(), testScores.end(), 0);
    testGradeAverage = static_cast<double>(total) / numberOfTestesScores;

    cout << "\nThe average grade for the test scores entered is " << testGradeAverage << "." << endl;

    return 0;
}
// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 4

#include <iostream>

using namespace std;

const int ROWS = 3;
const int COLUMNS = 4;

void printArray(int array[ROWS][COLUMNS]) {
    cout << "\nTest Data:" << endl;
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLUMNS; ++j) {
            cout << array[i][j] << " ";
        }
        cout << endl;
    }
}

int getHighestInRow(int array[ROWS][COLUMNS], int row) {
    int highest = array[row][0];
    for (int j = 1; j < COLUMNS; ++j) {
        if (array[row][j] > highest) {
            highest = array[row][j];
        }
    }
    return highest;
}

int getLowestInColumn(int array[ROWS][COLUMNS], int column) {
    int lowest = array[0][column];
    for (int i = 1; i < ROWS; ++i) {
        if (array[i][column] < lowest) {
            lowest = array[i][column];
        }
    }
    return lowest;
}

int main() {
    int testData[ROWS][COLUMNS] = {
        {78, 45, 67, 69},
        {40, 35, 99, 90},
        {11, 95, 16, 88}
    };

    cout << "A program that finds the lowest/highest values of either a row or column." << endl;
    cout << "Indexing starts at 1 for rows and columns." << endl;
    cout << "--------------------------------------------------------------\n" << endl;

    printArray(testData);

    int row, column;

    cout << "\nEnter a row of the test array shown above: ";
    cin >> row;
    row -= 1;
    if (row >= 0 && row < ROWS) {
        cout << "The highest value in row " << row + 1 << " is " << getHighestInRow(testData, row) << "." << endl;
    }
    else {
        cout << "Not a valid row input." << endl;
    }

    cout << "Enter a column of the array shown above: ";
    cin >> column;
    column -= 1;
    if (column >= 0 && column < COLUMNS) {
        cout << "The lowest value in column " << column + 1 << " is " << getLowestInColumn(testData, column) << "." << endl;
    }
    else {
        cout << "Not a valid column input." << endl;
    }

    return 0;
}
// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 9

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

string separateWords(const string & input) {
    string output;
    for (size_t i = 0; i < input.size(); ++i) {
        if (isupper(input[i]) && i != 0) {
            output += ' ';
            output += tolower(input[i]);
        }
        else {
            output += input[i];
        }
    }


    if (!output.empty()) {
        output[0] = toupper(output[0]);
        for (size_t i = 1; i < output.size() && output[i] != ' '; ++i) {
            output[i] = tolower(output[i]);
        }
    }
    return output;
}

int main() {
    string input;

    cout << "A simple program to fix a \"ran together\" sentence" << endl;
    cout << "--------------------------------------------------\n" << endl;

    cout << "Enter a run together sentence (capitalizing only the first letter of each word): ";
    getline(cin, input);

    string output = separateWords(input);
    cout << output << endl;

    return 0;
}
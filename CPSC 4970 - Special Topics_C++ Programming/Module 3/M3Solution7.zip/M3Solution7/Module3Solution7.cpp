// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 7

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

bool isLongEnough(const string& userPassword) {
    return userPassword.length() >= 6;
}

bool containsUpper(const string& userPassword) {
    for (char ch : userPassword) {
        if (isupper(ch)) {
            return true;
        }
    }
    return false;
}

bool containsLower(const string& userPassword) {
    for (char ch : userPassword) {
        if (islower(ch)) {
            return true;
        }
    }
    return false;
}

bool containsDigit(const string& userPassword) {
    for (char ch : userPassword) {
        if (isdigit(ch)) {
            return true;
        }
    }
    return false;
}

bool isValidPassword(const string& userPassword) {
    return isLongEnough(userPassword) && containsUpper(userPassword) && containsLower(userPassword) && containsDigit(userPassword);
}

int main() {
    string userPassword;

    cout << "A simple program to check the validity of a password." << endl;
    cout << "---------------------------------------------------\n" << endl;


    cout << "Enter a password: ";
    cin >> userPassword;

    if (isValidPassword(userPassword)) {
        cout << "Password is valid." << endl;
    }
    else {
        cout << "Password is invalid." << endl;
    }

    return 0;
}
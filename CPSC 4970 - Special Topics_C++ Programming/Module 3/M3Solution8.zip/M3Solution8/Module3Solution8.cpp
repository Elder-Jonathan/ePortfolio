// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 8

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main() {

    string inputLine;
    int letterCount[26] = { 0 }; // An array that stores the counts for each letter.

    cout << "A simple program to tally each char in a string" << endl;
    cout << "-----------------------------------------------\n" << endl;

    cout << "Enter text that you would like to compute: ";
    getline(cin, inputLine);

    // Convert all characters to lowercase and tally the total count.
    for (char ch : inputLine) {
        if (isalpha(ch)) {
            ch = tolower(ch);
            letterCount[ch - 'a']++;
        }
    }

    // Display results in alphabetical order.
    for (int i = 0; i < 26; ++i) {
        if (letterCount[i] > 0) {
            cout << letterCount[i] << " " << static_cast<char>(i + 'a') << endl;
        }
    }

    return 0;
}
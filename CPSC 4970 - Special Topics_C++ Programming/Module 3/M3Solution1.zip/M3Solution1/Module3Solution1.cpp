// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 1

#include <iostream>
#include <vector>

using namespace std;

const int NUM_OF_QUESTIONS = 20;

int main() {
    char correctAnswers[NUM_OF_QUESTIONS] = {
        'A', 'D', 'B', 'B', 'C', 'B', 'A', 'B', 'C', 'D',
        'A', 'C', 'D', 'B', 'D', 'C', 'C', 'A', 'D', 'B'
    };

    cout << "Welcome to the Driver's License Exam" << endl;
    cout << "------------------------------------\n" << endl;
    

    char studentAnswers[NUM_OF_QUESTIONS];
    for (int i = 0; i < NUM_OF_QUESTIONS; ++i) {
        char answer;
        bool valid;
        do {
            valid = true;
            cout << "Enter your answer for Question " << (i + 1) << " (A, B, C, or D): ";
            cin >> answer;
            answer = toupper(answer); // Converts the answer char to upcase each time.
            // If its not one of the 4 character choices then it is not a valid input.
            if (answer != 'A' && answer != 'B' && answer != 'C' && answer != 'D') {
                valid = false;
                cout << "\nNot a valid answer. Please enter only a single character! Either A, B, C, or D.\n" << endl;
            }
        } while (!valid);
        studentAnswers[i] = answer;
    }

    int correctAnswerCount = 0;
    vector<int> incorrectQuestions;
    for (int i = 0; i < NUM_OF_QUESTIONS; ++i) {
        if (studentAnswers[i] == correctAnswers[i]) {
            ++correctAnswerCount;
        }
        else {
            incorrectQuestions.push_back(i + 1);
        }
    }

    // "tostring" for results to be displayed.
    if (correctAnswerCount >= 15) {
        cout << "\nCongratulations! You have PASSED the exam!\n" << endl;
    }
    else {
        cout << "\nI am sorry to have to be the one to you... But you FAILED the exam.\n" << endl;
    }
    cout << "\nCorrect answers: " << correctAnswerCount << endl;
    cout << "Incorrect answers: " << (NUM_OF_QUESTIONS - correctAnswerCount) << endl;
    cout << endl;

    if (!incorrectQuestions.empty()) {
        cout << "Here are the questions you did not answer correctly: ";
        for (int q : incorrectQuestions) {
            cout << q << " ";
        }
        cout << endl;
    }

    return 0;
}
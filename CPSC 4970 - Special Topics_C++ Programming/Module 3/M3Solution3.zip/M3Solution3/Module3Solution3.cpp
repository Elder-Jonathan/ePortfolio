// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 3

#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main() {
    const int SIZE = 10;
    const int MAX_VALUE = 99;
    int numbers[SIZE];
    int counts[MAX_VALUE + 1] = { 0 };
    int temp;
    bool validInput;
    string input;

    cout << "A simple program that tallies each number entered." << endl;
    cout << "--------------------------------------------------\n" << endl;

    for (int i = 0; i < SIZE; i++) {
        validInput = false;
        while (!validInput) {
            if (i == 0) {
                cout << "Enter a number between 0 and 99: ";
            }
            else {
                cout << "Enter another integer between 0 and 99: ";
            }
            getline(cin, input);
            stringstream ss(input);

            if (ss >> temp && ss.eof() && temp >= 0 && temp <= 99) {
                numbers[i] = temp;
                validInput = true;
            }
            else {
                cout << "Please enter a valid INTEGER only value between 0 and 99." << endl;
            }
        }
    }

    // Count occurrences for a given number within the numbers array.
    for (int i = 0; i < SIZE; i++) {
        counts[numbers[i]]++;
    }

    // Shows the final total of counts of each number in the numbers array.
    for (int i = 0; i <= MAX_VALUE; i++) {
        if (counts[i] > 0) {
            cout << endl;
            cout << i << " occurs " << counts[i] << " time" << (counts[i] > 1 ? "s" : "") << endl;
        }
    }

    return 0;
}
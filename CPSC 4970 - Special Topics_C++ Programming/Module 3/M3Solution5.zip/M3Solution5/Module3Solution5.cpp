// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 3 Solution 5

#include <iostream>
#include <sstream>
#include <string>

using namespace std;

string intToString(int value) {
    ostringstream oss;
    oss << value;
    return oss.str();
}

void initializeBoard(char** board, int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            board[i][j] = '*';
        }
    }
}

void displayBoard(char** board, int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
}

bool makeMove(char** board, int player, int rows, int columns) {
    int row, col;
    char playerMark = (player == 1) ? 'X' : 'O';

    cout << "Player " << player << " (" << playerMark << "), enter your move (row space column): ";
    cin >> row >> col;

    row--; col--;

    if (row >= 0 && row < rows && col >= 0 && col < columns && board[row][col] == '*') {
        board[row][col] = playerMark;
        return true;
    }

    return false;
}

bool checkWin(char** board, char playerMark, int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        if ((board[i][0] == playerMark && board[i][1] == playerMark && board[i][2] == playerMark) ||
            (board[0][i] == playerMark && board[1][i] == playerMark && board[2][i] == playerMark)) {
            return true;
        }
    }
    return (board[0][0] == playerMark && board[1][1] == playerMark && board[2][2] == playerMark) ||
        (board[0][2] == playerMark && board[1][1] == playerMark && board[2][0] == playerMark);
}

bool checkTie(char** board, int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            if (board[i][j] == '*') {
                return false;
            }
        }
    }
    return true;
}

int main() {
    const int rows = 3, columns = 3;
    char** board = new char* [rows];
    for (int i = 0; i < rows; ++i) {
        board[i] = new char[columns];
    }

    initializeBoard(board, rows, columns);
    int currentPlayer = 1;
    bool gameWon = false, gameTied = false;

    while (!gameWon && !gameTied) {
        displayBoard(board, rows, columns);
        if (!makeMove(board, currentPlayer, rows, columns)) {
            cout << "Not a valid move! Please try again." << endl;
            continue;
        }
        gameWon = checkWin(board, (currentPlayer == 1) ? 'X' : 'O', rows, columns);
        gameTied = !gameWon && checkTie(board, rows, columns);
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    }

    displayBoard(board, rows, columns);
    cout << (gameWon ? "\nPlayer " + intToString((currentPlayer == 1) ? 2 : 1) + " wins!" : "\nIt is a tie!") << endl;

    for (int i = 0; i < rows; ++i) {
        delete[] board[i];
    }
    delete[] board;

    return 0;
}
// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 6 Solution 1
// NumDays.cpp

#include "NumDays.h"
#include <sstream>

using namespace std;

// The simple calculation needed to translate the number of total worked hours into total days worked
void NumDays::calcNumOfDays() {
    const double WORKDAY = 8.0;
    days = static_cast<double>(hours) / WORKDAY;
}

// Constructor that uses the default constructor.
NumDays::NumDays(int h) : hours(h) {
    calcNumOfDays();
}

// Getter and setter methods needed for the NumDays class.
int NumDays::getHours() const {
    return hours;
}

void NumDays::setHours(int totalHours) {
    hours = totalHours;
    calcNumOfDays();
}

double NumDays::getDays() const {
    return days;
}

// Method to get days and remaining hours as a formatted string.
string NumDays::getDaysAndHours() const {
    int fullDays = hours / 8;
    int remainingHours = hours % 8;
    std::ostringstream oss;
    oss << fullDays << " day(s) and " << remainingHours << " hour(s)";
    return oss.str();
}

// All the possibly needed Overloaded operator versions for the NumDay class.
NumDays NumDays::operator+(const NumDays& other) const {
    return NumDays(hours + other.hours);
}

NumDays NumDays::operator-(const NumDays& other) const {
    return NumDays(hours - other.hours);
}

NumDays& NumDays::operator++() {
    ++hours;
    calcNumOfDays();
    return *this;
}

NumDays NumDays::operator++(int) {
    NumDays temp = *this;
    hours++;
    calcNumOfDays();
    return temp;
}

NumDays& NumDays::operator--() {
    --hours;
    calcNumOfDays();
    return *this;
}

NumDays NumDays::operator--(int) {
    NumDays temp = *this;
    hours--;
    calcNumOfDays();
    return temp;
}
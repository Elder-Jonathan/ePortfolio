// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 6 Solution 1
// NumDaysTest.cpp


#include <iostream>
#include <iomanip>
#include <string>

#include "NumDays.h"

using namespace std;

int main() {
    string person1, person2;
    int totalHours1, totalHours2;

    cout << "A simple program that creates two NumDay objects as described and uses different overloaded versions of the function." << endl;
    cout << "---------------------------------------------------------------\n" << endl;

    cout << "Enter the first person's name: ";
    cin >> person1;
    cout << "How many hours did " << person1 << " work: ";
    cin >> totalHours1;

    NumDays nd1(totalHours1);

    cout << "Enter the second person's name: ";
    cin >> person2;
    cout << "How many hours did " << person2 << " work: ";
    cin >> totalHours2;

    NumDays nd2(totalHours2);

    cout << fixed << setprecision(2);
    cout << endl;
    cout << person1 << " worked " << nd1.getHours() << " hours, which is " << nd1.getDaysAndHours() << "." << endl;
    cout << person2 << " worked " << nd2.getHours() << " hours, which is " << nd2.getDaysAndHours() << "." << endl;
    cout << endl;
    NumDays nd3 = nd1 + nd2;
    cout << "Together, " << person1 << " and " << person2 << " worked " << nd3.getHours() << " hours, which is " << nd3.getDaysAndHours() << "." << endl;

    int hourDifference = abs(nd2.getHours() - nd1.getHours());
    int dayDifference = hourDifference / 8;
    int remainingHours = hourDifference % 8;

    if (nd2.getHours() >= nd1.getHours()) {
        cout << person2 << " worked " << hourDifference << " hours more than " << person1 << ", which is " << dayDifference << " day(s) and " << remainingHours << " hour(s) more." << endl;
    }
    else {
        cout << person2 << " worked " << hourDifference << " hours less than " << person1 << ", which is " << dayDifference << " day(s) and " << remainingHours << " hour(s) less." << endl;
    }
    cout << endl;
    cout << "Incrementing " << person1 << "'s hours (prefix): ";
    ++nd1;
    cout << person1 << " now worked " << nd1.getHours() << " hours, which is " << nd1.getDaysAndHours() << "." << endl;

    cout << "Incrementing " << person2 << "'s hours (postfix): ";
    nd2++;
    cout << person2 << " now worked " << nd2.getHours() << " hours, which is " << nd2.getDaysAndHours() << "." << endl;

    cout << "Decrementing " << person1 << "'s hours (prefix): ";
    --nd1;
    cout << person1 << " now worked " << nd1.getHours() << " hours, which is " << nd1.getDaysAndHours() << "." << endl;

    cout << "Decrementing " << person2 << "'s hours (postfix): ";
    nd2--;
    cout << person2 << " now worked " << nd2.getHours() << " hours, which is " << nd2.getDaysAndHours() << "." << endl;

    return 0;
}
// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 6 Solution 1
// NumDays.h

#ifndef NUMDAYS_H
#define NUMDAYS_H

#include <string>

class NumDays {

private:
    int hours;
    double days;
    void calcNumOfDays();

public:
    // Default constructor representation that also works to initialize variable to 0 as well.
    NumDays(int h = 0);

    // Getter and Setter functions for the class.
    int getHours() const;
    double getDays() const;
    void setHours(int h);

    // Method to get days and remaining hours as a formatted string
    std::string getDaysAndHours() const;

    // All the needed overloaded versions using the class NumDays
    NumDays& operator++();
    NumDays& operator--();
    NumDays operator++(int);
    NumDays operator--(int);
    NumDays operator+(const NumDays& other) const;
    NumDays operator-(const NumDays& other) const;
};

#endif
// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 6 Solution 4
// Test.cpp

#include <iostream>
#include "DivSales.h"

using namespace std;

int main()
{

    cout << "A simple program that takes user defined data for 6 sales divisions. " << endl;
    cout << "---------------------------------------------------\n" << endl;
    const int NUM_DIVISIONS = 6;
    DivSales divisions[NUM_DIVISIONS];
    double q1, q2, q3, q4;

    // Get sales data for each division.
    for (int i = 0; i < NUM_DIVISIONS; i++)
    {
        cout << "Enter sales for Division " << (i + 1) << " for four quarters (separated by spaces): ";

        cin >> q1 >> q2 >> q3 >> q4;

        while (q1 < 0 || q2 < 0 || q3 < 0 || q4 < 0)
        {
            cout << "Invalid input. Enter positive values for all four quarters: ";
            cin >> q1 >> q2 >> q3 >> q4;
        }

        // Set sales data for the division.
        divisions[i].setQuarterlySales(q1, q2, q3, q4);
    }

    // Display the sales data for each division.
    cout << "\nDivision Sales:\n";
    cout << "Division\tQ1\tQ2\tQ3\tQ4\n";
    for (int i = 0; i < NUM_DIVISIONS; i++)
    {
        cout << "Division " << (i + 1) << ":\t";
        for (int j = 0; j < 4; j++)
        {
            cout << divisions[i].getQuarterlySales(j) << "\t";
        }
        cout << endl;
    }

    // Display total corporate sales.
    cout << "\nTotal Corporate Sales: " << DivSales::getTotalCorporateSales() << endl;

    return 0;
}
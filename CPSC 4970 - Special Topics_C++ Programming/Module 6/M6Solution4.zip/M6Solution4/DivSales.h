// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 6 Solution 4
// DivSales.h

#ifndef DIVSALES_H
#define DIVSALES_H

class DivSales
{
private:
    double quarterlySales[4]; // An array of 4 quarter for each of the 6 sales divisions.
    static double totalCorporateSales; // Static variable.

public:
    // Constructor
    DivSales();

    // Member function to set quarterly sales.
    void setQuarterlySales(double q1, double q2, double q3, double q4);

    // Member function to get sales for a specific quarter.
    double getQuarterlySales(int quarter) const;

    // Static function to get total corporate sales.
    static double getTotalCorporateSales();
};

#endif

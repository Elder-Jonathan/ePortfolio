#include "DivSales.h"

// Initialize static member
double DivSales::totalCorporateSales = 0.0;

// Constructor
DivSales::DivSales()
{
    for (int i = 0; i < 4; i++)
        quarterlySales[i] = 0.0;
}

// Member function to set quarterly sales
void DivSales::setQuarterlySales(double q1, double q2, double q3, double q4)
{
    quarterlySales[0] = q1;
    quarterlySales[1] = q2;
    quarterlySales[2] = q3;
    quarterlySales[3] = q4;

    totalCorporateSales += (q1 + q2 + q3 + q4);
}

// Member function to get sales for a specific quarter
double DivSales::getQuarterlySales(int quarter) const
{
    if (quarter >= 0 && quarter < 4)
        return quarterlySales[quarter];
    else
        return 0.0; // Return 0 if the quarter is out of range
}

// Static function to get total corporate sales
double DivSales::getTotalCorporateSales()
{
    return totalCorporateSales;
}
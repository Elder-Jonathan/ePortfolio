// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 6 Solution 3
// FeetInches.cpp mostly created following along with video.

#include <cstdlib>
#include "FeetInches.h"

// Definition of the member function simplify.
void FeetInches::simplify()
{
    if (inches >= 12)
    {
        feet += (inches / 12);
        inches = inches % 12;
    }
    else if (inches < 0)
    {
        feet -= ((abs(inches) / 12) + 1);
        inches = 12 - (abs(inches) % 12);
    }
}

// Overloaded binary + operator.
FeetInches FeetInches::operator + (const FeetInches& right)
{
    FeetInches temp;
    temp.inches = inches + right.inches;
    temp.feet = feet + right.feet;
    temp.simplify();
    return temp;
}

// Overloaded binary - operator.
FeetInches FeetInches::operator - (const FeetInches& right)
{
    FeetInches temp;
    temp.inches = inches - right.inches;
    temp.feet = feet - right.feet;
    temp.simplify();
    return temp;
}

// Overloaded prefix ++ operator.
FeetInches FeetInches::operator++()
{
    ++inches;
    simplify();
    return *this;
}

// Overloaded postfix ++ operator.
FeetInches FeetInches::operator++(int)
{
    FeetInches temp(feet, inches);
    inches++;
    simplify();
    return temp;
}

// Overloaded > operator.
bool FeetInches::operator > (const FeetInches& right)
{
    if (feet > right.feet)
        return true;
    else if (feet == right.feet && inches > right.inches)
        return true;
    else
        return false;
}

// Overloaded < operator.
bool FeetInches::operator < (const FeetInches& right)
{
    if (feet < right.feet)
        return true;
    else if (feet == right.feet && inches < right.inches)
        return true;
    else
        return false;
}

// Overloaded == operator.
bool FeetInches::operator == (const FeetInches& right)
{
    if (feet == right.feet && inches == right.inches)
        return true;
    else
        return false;
}

// Overloaded <= operator.
bool FeetInches::operator <= (const FeetInches& right)
{
    return !(*this > right);
}

// Overloaded >= operator.
bool FeetInches::operator >= (const FeetInches& right)
{
    return !(*this < right);
}

// Overloaded != operator.
bool FeetInches::operator != (const FeetInches& right)
{
    return !(*this == right);
}
// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 6 Solution 3
// FeetInches.h mostly created following along with video.

#ifndef FEETINCHES_H
#define FEETINCHES_H

// The FeetInches class holds distances or measurements 
// expressed in feet and inches.

class FeetInches
{
private:
    int feet;
    int inches;
    void simplify();
public:
    // Constructors
    FeetInches()
    {
        feet = 0;
        inches = 0;
    }

    FeetInches(int f, int i)
    {
        feet = f;
        inches = i;
        simplify();
    }

    // Mutator functions
    void setFeet(int f)
    {
        feet = f;
    }

    void setInches(int i)
    {
        inches = i;
        simplify();
    }

    // Accessor functions
    int getFeet() const
    {
        return feet;
    }

    int getInches() const
    {
        return inches;
    }

    // Overloaded operator functions
    FeetInches operator + (const FeetInches&);
    FeetInches operator - (const FeetInches&);
    FeetInches operator ++ ();
    FeetInches operator ++ (int);
    bool operator > (const FeetInches&);
    bool operator < (const FeetInches&);
    bool operator == (const FeetInches&);
    bool operator <= (const FeetInches&);
    bool operator >= (const FeetInches&);
    bool operator != (const FeetInches&);
};

#endif

// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 6 Solution 3
// UpdatedTest.cpp

#include <iostream>
#include "FeetInches.h"

using namespace std;

int main()
{
    int feet, inches;

    cout << "A simple program that creates two user defined FeetInches objects and creates a third." << endl;
    cout << "-------------------------------------------------\n" << endl;

    // Create three FeetInches objects. The default arguments for the constructor will be used.
    FeetInches first, second, third;

    // Get a distance from the user.
    cout << "Enter a distance in feet and inches: ";
    cin >> feet >> inches;

    // Store the distance in first.
    first.setFeet(feet);
    first.setInches(inches);

    // Get another distance.
    cout << "Enter another distance in feet and inches: ";
    cin >> feet >> inches;

    // Store the distance in second.
    second.setFeet(feet);
    second.setInches(inches);

    // Assign first + second to third.
    third = first + second;

    // Displays the results.
    cout << "first + second = ";
    cout << third.getFeet() << " feet, ";
    cout << third.getInches() << " inches.\n";

    // Assign (first - second) to the "third" newly created object.
    third = first - second;

    // Displays the results.
    cout << "first - second = ";
    cout << third.getFeet() << " feet, ";
    cout << third.getInches() << " inches.\n";

    // Compare the two user defined objects.
    if (first == second)
        cout << "The first object is equal to the second object.\n";
    if (first > second)
        cout << "The first object  is greater than the second object.\n";
    if (first < second)
        cout << "The first object is less than the second object.\n";
    if (first >= second)
        cout << "The first object is greater than or equal to the second object.\n";
    if (first <= second)
        cout << "The first object is less than or equal to the second object.\n";
    if (first != second)
        cout << "The first object  is not equal to the second object.\n";

    // Using the prefix version of the ++ operator.
    cout << "Demonstration using the prefix ++ operator.\n";
    for (int count = 0; count < 12; count++)
    {
        first = ++second;
        cout << "first: " << first.getFeet() << " feet, ";
        cout << first.getInches() << " inches. ";
        cout << "second: " << second.getFeet() << " feet, ";
        cout << second.getInches() << " inches.\n";
    }

    // Using the postfix version of the ++ operator.
    cout << "\nDemonstration using the postfix ++ operator.\n";
    for (int count = 0; count < 12; count++)
    {
        first = second++;
        cout << "first: " << first.getFeet() << " feet, ";
        cout << first.getInches() << " inches. ";
        cout << "second: " << second.getFeet() << " feet, ";
        cout << second.getInches() << " inches.\n";
    }

    return 0;
} 
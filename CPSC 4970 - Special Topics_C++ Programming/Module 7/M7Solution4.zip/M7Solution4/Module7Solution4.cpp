// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 7 Solution 4
// Module7Solution4.cpp

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <set>
#include <sstream>
#include <cctype>

using namespace std;

// This is a different way than I used before, but converts everything to lower case
// as to not list the same word more than once.
string toLower(const string& str) {
    string lowerStr;
    for (char ch : str) {
        lowerStr += tolower(ch);
    }
    return lowerStr;
}

// This function will process and make a file, based on the word indexing.
void buildWordIndex(const string& inputFileName, const string& outputFileName) {
    ifstream inputFile(inputFileName);
    if (!inputFile) {
        cerr << "Error opening input file: " << inputFileName << endl;
        return;
    }

    map<string, set<int>> wordMap;
    string line;
    int lineNumber = 0;

    while (getline(inputFile, line)) {
        ++lineNumber;
        stringstream lineStream(line);
        string word;
        while (lineStream >> word) {
            string cleanedWord;
            for (char ch : word) {
                if (isalnum(ch)) {
                    cleanedWord += tolower(ch);
                }
            }
            wordMap[cleanedWord].insert(lineNumber);
        }
    }

    inputFile.close();

    ofstream outputFile(outputFileName);
    if (!outputFile) {
        cerr << "There seems to have been an error writing to the output file: " << outputFileName << endl;
        return;
    }

    for (const auto& entry : wordMap) {
        outputFile << entry.first << ": ";
        for (const auto& lineNum : entry.second) {
            outputFile << lineNum << " ";
        }
        outputFile << endl;
    }

    outputFile.close();
}

int main() {
    string inputFileName, outputFileName;

    cout << "A simple program that reads a user defined file, and writes it to an output file after processing." << endl;
    cout << "------------------------------------------------------------------\n" << endl;

    cout << "Enter the input file name (within the project directories scope): ";
    cin >> inputFileName;

    cout << "Enter the name of the file you would like to create and output to: ";
    cin >> outputFileName;

    buildWordIndex(inputFileName, outputFileName);

    cout << "The word index was successfully created and saved as " << outputFileName << " in your root directory." << endl;

    return 0;
}
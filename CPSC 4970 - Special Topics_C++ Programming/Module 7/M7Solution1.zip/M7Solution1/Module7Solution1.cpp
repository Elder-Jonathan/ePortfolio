// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 7 Solution 1

#include <iostream>
#include <stdexcept>
#include <string>
#include <map>

using namespace std;

class Date {
private:

    int month, day, year;

    map<int, string> monthNames{
        {1, "January"}, {2, "February"}, {3, "March"}, {4, "April"}, {5, "May"}, {6, "June"}, {7, "July"}, {8, "August"},
        {9, "September"}, {10, "October"}, {11, "November"}, {12, "December"}
    };

public:
    class InvalidDay : public exception {
    public:
        const char* what() const noexcept override {
            return "\tNot a valid Day selection. Day value must be between 1 and 31 only.";
        }
    };

    class InvalidMonth : public exception {
    public:
        const char* what() const noexcept override {
            return "\tNot a valid Month selection. Enter an INT value ONLY between 1 and 12.";
        }
    };

    class InvalidYear : public exception {
    public:
        const char* what() const noexcept override {
            return "Not a valid Year selection. Only enter a Year between 1920 and 2030.";
        }
    };

    Date(int m, int d, int y) : month(m), day(d), year(y) {
        if (month < 1 || month > 12) throw InvalidMonth();
        if (day < 1 || day > 31) throw InvalidDay();
        if (year < 1920 || year > 2030) throw InvalidYear();
    }

    void firstFormatType() const {
        cout << "\t" << month << "/" << day << "/" << year << endl;
    }

    void secondFormatType() const {
        cout << "\t" <<  monthNames.at(month) << " " << day << ", " << year << endl;
    }

    void thirdFormatType() const {
        cout << "\t" << day << " " << monthNames.at(month) << " " << year << endl;
    }
};

int main() {

    int month, day, year;
    bool validInput = false;

    cout << "A simple program that formats a user input Date object and checks for validation." << endl;
    cout << "----------------------------------------------------------------\n" << endl;

    while (!validInput) {
        try {
            cout << "Enter a month (enter an int value): ";
            cin >> month;
            if (month < 1 || month > 12) throw Date::InvalidMonth();
            validInput = true;
        }
        catch (const Date::InvalidMonth& exception) {
            cerr << exception.what() << endl;
        }
    }

    validInput = false;

    while (!validInput) {
        try {
            cout << "Enter a day: ";
            cin >> day;
            if (day < 1 || day > 31) throw Date::InvalidDay();
            validInput = true;
        }
        catch (const Date::InvalidDay& exception) {
            cerr << exception.what() << endl;
        }
    }

    validInput = false;
    while (!validInput) {
        try {
            cout << "Enter a year: ";
            cin >> year;
            if (year < 1920 || year > 2030) throw Date::InvalidYear();
            validInput = true;
        }
        catch (const Date::InvalidYear& exception) {
            cerr << exception.what() << endl;
        }
    }

    try {
        Date date(month, day, year);
        cout << "\nFormatted Date Versions:" << endl;
        date.firstFormatType();
        date.secondFormatType();
        date.thirdFormatType();
    }
    catch (const Date::InvalidDay& exception) {
        cerr << exception.what() << endl;
    }
    catch (const Date::InvalidMonth& exception) {
        cerr << exception.what() << endl;
    }
    catch (const Date::InvalidYear& exception) {
        cerr << exception.what() << endl;
    }

    return 0;
}
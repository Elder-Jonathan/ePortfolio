// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 7 Solution 3
// Module7Solution3.cpp

#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <string>
#include <cctype>
#include <algorithm>

using namespace std;

void processFile(const string& fileToProcess) {
    ifstream fileName(fileToProcess);
    if (!fileName) {
        cerr << "The was an error opening and processing the file: " << fileToProcess << endl;
        return;
    }

    unordered_map<string, int> wordFrequency;
    vector<string> orderOfWords;
    string currentLine;

    while (getline(fileName, currentLine)) {

        // Convert line to lowercase as to not repeat any words.
        transform(currentLine.begin(), currentLine.end(), currentLine.begin(), ::tolower);
        // Remove punctuation from the line if there is any.
        currentLine.erase(remove_if(currentLine.begin(), currentLine.end(), ::ispunct), currentLine.end());

        stringstream ss(currentLine);
        string wordBeingParsed;

        while (ss >> wordBeingParsed) {
            if (wordFrequency.find(wordBeingParsed) == wordFrequency.end()) {
                orderOfWords.push_back(wordBeingParsed);
                wordFrequency[wordBeingParsed] = 1;
            }
            else {
                wordFrequency[wordBeingParsed]++;
            }
        }
    }

    fileName.close();

    // Display the word frequencies in the order they were read
    cout << "Word Frequency Generator:" << endl;
    for (const auto& word : orderOfWords) {
        cout<< "\t" << word << ": " << wordFrequency[word] << endl;
    }
}

int main() {
    string fileToProcess;

    cout << "A simple program that reads a file and tallies each word used. " << endl;
    cout << "------------------------------------------------\n" << endl;

    cout << "Enter the name of the file you would like to process: ";
    cin >> fileToProcess;
    cout << endl;

    processFile(fileToProcess);

    return 0;
}
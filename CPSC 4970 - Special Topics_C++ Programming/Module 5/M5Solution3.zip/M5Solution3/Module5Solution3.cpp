// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 5 Solution 3

#include <iostream>
#include <iomanip>
#include <string>
#include <memory>
#include <limits>

using namespace std;

struct Student {
    string name;
    int id;
    unique_ptr<double[]> tests;
    double average;
    char grade;
};

void getStudentData(Student*, int, int);
void calculateCourseGrades(Student*, int, int);
char calculateGrade(double);
double calculateClassAverage(Student*, int);

int main() {
    string courseName;
    int numOfStudents, numOfTests;

    cout << "A simplish program that keeps up with a gradebook for a user defined course." << endl;
    cout << "------------------------------------------------------------------\n" << endl;

    cout << "Enter the course name: ";
    getline(cin, courseName);

    cout << "How many students are in this course: ";
    while (!(cin >> numOfStudents) || numOfStudents <= 0) {
        cout << "Not a valid input! ONLY use positive integer values for entering the number of students: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "How many tests are there for this course: ";
    while (!(cin >> numOfTests) || numOfTests <= 0) {
        cout << "Not a valid input! ONLY use positive integer values for entering the number of tests: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    auto students = make_unique<Student[]>(numOfStudents);

    for (int i = 0; i < numOfStudents; ++i) {
        students[i].tests = make_unique<double[]>(numOfTests);
    }

    getStudentData(students.get(), numOfStudents, numOfTests);
    calculateCourseGrades(students.get(), numOfStudents, numOfTests);

    cout << fixed << setprecision(2);
    cout << "\nCourse Grades for " << courseName << ":\n";
    cout << "-----------------------------------------\n";
    cout << "-----------------------------------------\n";
    cout << left << setw(20) << "Name" << setw(10) << "ID" << setw(10) << "Average" << setw(5) << "Grade" << endl;
    cout << "-----------------------------------------\n";
    for (int i = 0; i < numOfStudents; ++i) {
        cout << left << setw(20) << students[i].name
            << setw(10) << students[i].id
            << setw(10) << students[i].average
            << setw(5) << students[i].grade
            << endl;
    }
    cout << "-----------------------------------------\n";

    double classAverage = calculateClassAverage(students.get(), numOfStudents);
    cout << "Overall Class Average: " << classAverage << "\n";

    return 0;
}

void getStudentData(Student* students, int numOfStudents, int numOfTests) {
    cin.ignore();
    for (int i = 0; i < numOfStudents; ++i) {
        cout << "\nEnter info for student " << (i + 1) << ":\n";
        cout << "\tName: ";
        getline(cin, students[i].name);
        cout << "\tID: ";
        cin >> students[i].id;
        cout << "\nEnter the test scores:\n";
        for (int j = 0; j < numOfTests; ++j) {
            cout << "\tTest " << (j + 1) << ": ";
            while (!(cin >> students[i].tests[j]) || students[i].tests[j] < 0) {
                cout << "Not a valid input! Please enter a number between 0 and 100." << (j + 1) << ": ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }
        cin.ignore();
    }
}

void calculateCourseGrades(Student* students, int numOfStudents, int numOfTests) {
    for (int i = 0; i < numOfStudents; ++i) {
        double total = 0.0;
        for (int j = 0; j < numOfTests; ++j) {
            total += students[i].tests[j];
        }
        students[i].average = total / numOfTests;
        students[i].grade = calculateGrade(students[i].average);
    }
}

char calculateGrade(double average) {
    if (average >= 91) return 'A';
    else if (average >= 81) return 'B';
    else if (average >= 71) return 'C';
    else if (average >= 61) return 'D';
    else return 'F';
}

double calculateClassAverage(Student* students, int numOfStudents) {
    double totalAverage = 0.0;
    for (int i = 0; i < numOfStudents; ++i) {
        totalAverage += students[i].average;
    }
    return totalAverage / numOfStudents;
}
// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 5 Solution 5

#include <iostream>
#include <string>

using namespace std;

class Car {
private:
    int yearModel;
    string make;
    string model;
    int speed;

public:
    // Constructor for class.
    Car(int year, string carMake, string carModel) : yearModel(year), make(carMake), model(carModel), speed(0) {}

    // General getters and setters for all needed variables.
    int getYearModel() const {
        return yearModel;
    }

    string getMake() const {
        return make;
    }

    string getModel() const {
        return model;
    }

    int getSpeed() const {
        return speed;
    }

    void setYearModel(int year) {
        yearModel = year;
    }

    void setMake(string carMake) {
        make = carMake;
    }

    void setModel(string carModel) {
        model = carModel;
    }

    void setSpeed(int carSpeed) {
        speed = carSpeed;
    }

    // Accelerate function
    void accelerate(int value) {
        if (value >= 0 && value <= 20) {
            speed += value;
        }
        else {
            cout << "Not a valid acceleration value. Pick an INT between 0 and 20." << endl;
        }
    }

    void brake(int value) {
        if (value >= 0 && value <= 20) {
            speed -= value;
            if (speed < 0) {
                speed = 0;
            }
        }
        else {
            cout << "Not a valid brake value. Pick an INT between 0 and 20." << endl;
        }
    }
};

int main() {
    string make, model;
    int year, accelerateValue, brakeValue;

    cout << "A simple program to simulate a user defined car." << endl;
    cout << "----------------------------------------------\n" << endl;

    cout << "Enter the make of the car to simulate: ";
    cin >> make;

    cout << "Enter the model of the car to simulate: ";
    cin >> model;

    cout << "Enter the year of the car to simulate: ";
    cin >> year;

    // Creates a simple Car object to be used in simulation.
    Car myCar(year, make, model);

    cout << "Enter an acceleration value (0-20): ";
    cin >> accelerateValue;

    cout << "Enter a braking value (0-20): ";
    cin >> brakeValue;

    cout << "\nPress Enter to start accelerating...";
    cin.ignore();
    cin.get(); // Waits for user to press enter to start the sim.

    // Accelerate the car 5 times as descibed as needed.
    for (int i = 0; i < 5; ++i) {
        myCar.accelerate(accelerateValue);
        cout << "Current speed after accelerate " << (i + 1) << ": " << myCar.getSpeed() << " mph" << endl;
        cout << "Press Enter to continue accelerating...";
        cin.get(); // Wait for user to press Enter
    }

    // Same prompt to continue simulation.
    cout << "\nPress Enter to start braking...";
    cin.get(); // Wait for user to press Enter

    // Brakes the car 5 times  as described is needed.
    for (int i = 0; i < 5; ++i) {
        myCar.brake(brakeValue);
        cout << "Current speed after brake " << (i + 1) << ": " << myCar.getSpeed() << " mph" << endl;
        cout << "Press Enter to continue braking...";
        cin.get(); // Wait for user to press Enter
    }

    // Final output before exiting program.
    cout << "\nVehicle: " << myCar.getMake() << " " << myCar.getModel() << " " << myCar.getYearModel() << endl;
    cout << "Final speed: " << myCar.getSpeed() << " mph" << endl;

    return 0;
}
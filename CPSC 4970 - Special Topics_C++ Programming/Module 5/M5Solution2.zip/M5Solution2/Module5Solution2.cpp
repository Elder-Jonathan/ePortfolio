// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 5 Solution 2

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

struct WeatherData {
    double totalRainfall;
    double highestTemp;
    double lowestTemp;
    double averageTemp;
};

enum Months { JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER, MONTHS_COUNT };
const string monthNames[MONTHS_COUNT] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

void userWeatherData(WeatherData[]);
void calcWeatherData(const WeatherData[], double&, double&, double&, string&, double&, string&, double&);

int main() {
    int yearEntered;
    WeatherData weatherForYear[MONTHS_COUNT];

    cout << "A simple program that takes user input for weather statistics and then displays calculated results." << endl;
    cout << "This time with enum representation!" << endl;
    cout << "---------------------------------------------------------------------------\n" << endl;

    cout << "Enter the year for which you would like to enter weather statistics: ";
    cin >> yearEntered;

    userWeatherData(weatherForYear);

    double avgMonthlyRainfall = 0, totalRainfall = 0, highestTemp = 0, lowestTemp = 0, averageTotalTemp = 0;
    string monthHighestTemp, monthLowestTemp;

    calcWeatherData(weatherForYear, avgMonthlyRainfall, totalRainfall, highestTemp, monthHighestTemp, lowestTemp, monthLowestTemp, averageTotalTemp);

    cout << fixed << setprecision(2);
    cout << "\nWeather Statistics for the Year " << yearEntered << endl;
    cout << "---------------------------\n" << endl;
    cout << "\tAverage Monthly Rainfall: " << avgMonthlyRainfall << " inches" << endl;
    cout << "\tTotal Rainfall For Year: " << totalRainfall << " inches" << endl;
    cout << "\tThe Highest Temperature was " << highestTemp << " degrees in " << monthHighestTemp << endl;
    cout << "\tThe Lowest Temperature was " << lowestTemp << " degrees in " << monthLowestTemp << endl;
    cout << "\tThe average temperature for the year was: " << averageTotalTemp << " degrees" << endl;

    return 0;
}

void userWeatherData(WeatherData weatherForYear[]) {
    for (int month = JANUARY; month < MONTHS_COUNT; ++month) {
        cout << "Enter data for " << monthNames[month] << ":" << endl;
        cout << "\tTotal rainfall for the month: ";
        cin >> weatherForYear[month].totalRainfall;
        cout << "\tHighest temperature reached during the month: ";
        cin >> weatherForYear[month].highestTemp;
        cout << "\tLowest temperature reached during the month: ";
        cin >> weatherForYear[month].lowestTemp;
        weatherForYear[month].averageTemp = (weatherForYear[month].highestTemp + weatherForYear[month].lowestTemp) / 2.0;
    }
}

void calcWeatherData(const WeatherData weatherForYear[], double& avgMonthlyRainfall, double& totalRainfall, double& highestTemp, string& monthHighestTemp, double& lowestTemp, string& monthLowestTemp, double& averageTotalTemp) {
    totalRainfall = 0;
    highestTemp = weatherForYear[0].highestTemp;
    lowestTemp = weatherForYear[0].lowestTemp;
    double sumOfAvgTemps = 0;

    for (int month = JANUARY; month < MONTHS_COUNT; ++month) {
        totalRainfall += weatherForYear[month].totalRainfall;
        sumOfAvgTemps += weatherForYear[month].averageTemp;

        if (weatherForYear[month].highestTemp > highestTemp) {
            highestTemp = weatherForYear[month].highestTemp;
            monthHighestTemp = monthNames[month];
        }

        if (weatherForYear[month].lowestTemp < lowestTemp) {
            lowestTemp = weatherForYear[month].lowestTemp;
            monthLowestTemp = monthNames[month];
        }
    }

    avgMonthlyRainfall = totalRainfall / MONTHS_COUNT;
    averageTotalTemp = sumOfAvgTemps / MONTHS_COUNT;
}
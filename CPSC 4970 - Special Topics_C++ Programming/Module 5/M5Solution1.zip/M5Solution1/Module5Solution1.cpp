// Jonathan Elder
// CPSC 4970 C++ Programming
// Module 5 Solution 1

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

struct WeatherData {
    double totalRainfall;
    double highestTemp;
    double lowestTemp;
    double averageTemp;
};

const int MONTHS = 12;
const string namesOfMonths[MONTHS] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

void userWeatherData(WeatherData[]);
void calcWeatherData(const WeatherData[], double&, double&, double&, string&, double&, string&, double&);

int main() {
    int yearEntered;
    WeatherData weatherForYear[MONTHS];

    cout << "A simple program that takes user input for weather statistics and then displays calculated results." << endl;
    cout << "---------------------------------------------------------------------------\n" << endl;

    cout << "Enter the year for which you would like to enter weather statistics: ";
    cin >> yearEntered;

    userWeatherData(weatherForYear);

    double avgMonthlyRainfall, totalRainfall, highestTemp, lowestTemp, averageTotalTemp;
    string monthHighestTemp, monthLowestTemp;

    calcWeatherData(weatherForYear, avgMonthlyRainfall, totalRainfall, highestTemp, monthHighestTemp, lowestTemp, monthLowestTemp, averageTotalTemp);

    cout << fixed << setprecision(2);
    cout << "\nWeather Statistics for the Year " << yearEntered << endl;
    cout << "---------------------------\n" << endl;
    cout << "\tAverage Monthly Rainfall: " << avgMonthlyRainfall << " inches" << endl;
    cout << "\tTotal Rainfall For Year: " << totalRainfall << " inches" << endl;
    cout << "\tThe Highest Temperature was " << highestTemp << " degrees in " << monthHighestTemp << endl;
    cout << "\tThe Lowest Temperature was " << lowestTemp << " degrees in " << monthLowestTemp << endl;
    cout << "\tThe average temperature for the year was: " << averageTotalTemp << " degrees" << endl;

    return 0;
}

void userWeatherData(WeatherData weatherForYear[]) {
    for (int i = 0; i < MONTHS; ++i) {
        cout << "Enter data for " << namesOfMonths[i] << ":" << endl;
        cout << "\tTotal rainfall for the month: ";
        cin >> weatherForYear[i].totalRainfall;
        cout << "\tHighest temperature reached during the month: ";
        cin >> weatherForYear[i].highestTemp;
        cout << "\tLowest temperature reached during the month: ";
        cin >> weatherForYear[i].lowestTemp;
        weatherForYear[i].averageTemp = (weatherForYear[i].highestTemp + weatherForYear[i].lowestTemp) / 2.0;
    }
}

void calcWeatherData(const WeatherData weatherForYear[], double& avgMonthlyRainfall, double& totalRainfall, double& highestTemp, string& monthHighestTemp, double& lowestTemp, string& monthLowestTemp, double& averageTotalTemp) {
    totalRainfall = 0;
    highestTemp = weatherForYear[0].highestTemp;
    lowestTemp = weatherForYear[0].lowestTemp;
    double sumOfAvgTemps = 0;

    for (int i = 0; i < MONTHS; ++i) {
        totalRainfall += weatherForYear[i].totalRainfall;
        sumOfAvgTemps += weatherForYear[i].averageTemp;

        if (weatherForYear[i].highestTemp > highestTemp) {
            highestTemp = weatherForYear[i].highestTemp;
            monthHighestTemp = namesOfMonths[i];
        }

        if (weatherForYear[i].lowestTemp < lowestTemp) {
            lowestTemp = weatherForYear[i].lowestTemp;
            monthLowestTemp = namesOfMonths[i];
        }
    }

    avgMonthlyRainfall = totalRainfall / MONTHS;
    averageTotalTemp = sumOfAvgTemps / MONTHS;
}
// Jonathan Elder
// CPSC 4970 - C++ Programming
// Module 5 Solution 6

#include <iostream>
#include <string>
#include <vector>
#include <array>

using namespace std;

class Question {
private:
    string question;
    array<string, 4> answers;
    int correctAnswer;

public:
    // Constructor
    Question(const string& q, const string& ans1, const string& ans2, const string& ans3, const string& ans4, int correct)
        : question(q), answers{ ans1, ans2, ans3, ans4 }, correctAnswer(correct) {}

    string getQuestion() const {
        return question;
    }

    string getAnswer(int index) const {
        if (index >= 0 && index < 4) {
            return answers[index];
        }
        return "";
    }

    int getCorrectAnswer() const {
        return correctAnswer;
    }

    // Function that will ask a question from the database and retrieve its answer.
    bool askQuestion() const {
        cout << question << endl;
        for (int i = 0; i < 4; ++i) {
            cout << (i + 1) << ". " << answers[i] << endl;
        }
        int playerAnswer;
        while (true) {
            cout << "Your answer (enter 1, 2, 3 or 4): ";
            cin >> playerAnswer;
            if (cin.fail() || playerAnswer < 1 || playerAnswer > 4) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input. Please enter a number between 1 and 4." << endl;
            }
            else {
                break;
            }
        }
        return playerAnswer == correctAnswer;
    }
};

void playGame(vector<Question>& questions, int startIndex, int endIndex, int& playerPoints, const string& playerName) {
    cout << "\n" << playerName << ", it's your turn to answer your selected questions!\n" << endl;
    for (int i = startIndex; i < endIndex; ++i) {
        if (questions[i].askQuestion()) {
            playerPoints++;
            cout << "Correct!" << endl;
        }
        else {
            cout << "Wrong!" << endl;
        }
        cout << endl;
    }
}

int main() {
    cout << "A simple program that starts a partially \"Auburn Themed\" Trivia game and returns a winner!" << endl;
    cout << "--------------------------------------------------------------------------\n" << endl;

    vector<Question> questions = {
        {"What is the most popular game of all time?", "Final Fantasy", "Gears of War", "Halo", "Call of Duty", 3},
        {"What is 3 + 3?", "3", "4", "5", "6", 4},
        {"Who is going to win the national championship this year?", "Auburn", "Alabama", "USC", "Georgia", 1},
        {"Who won the national championship in men's golf 2024?", "North Carolina", "Duke", "Auburn", "Alabama", 3},
        {"Who won the SEC men's basketball tournament in 2024?", "Kentucky", "Auburn", "Alabama", "Georgia", 2},
        {"What is 3 * 8?", "11", "30", "24", "44", 3},
        {"What is 5 * 6?", "30", "35", "25", "40", 1},
        {"Who won the national championship for the 4 x 100 men's track and field in 2024?", "Alabama", "Duke", "Auburn", "Ohio State", 3},
        {"What is the smallest prime number?", "0", "1", "2", "3", 3},
        {"What is the speed of light?", "299,792 km/s", "299,792 m/s", "299,792 km/h", "299,792 m/h", 1}
    };

    int player1Points = 0, player2Points = 0;

    playGame(questions, 0, 5, player1Points, "Player 1");
    playGame(questions, 5, 10, player2Points, "Player 2");

    cout << "\nTrivia Game Results:" << endl;
    cout << "-----------------" << endl;
    cout << "Player 1: " << player1Points << " points" << endl;
    cout << "Player 2: " << player2Points << " points" << endl;

    if (player1Points > player2Points) {
        cout << "Player 1 wins the trivia game!" << endl;
    }
    else if (player2Points > player1Points) {
        cout << "Player 2 wins the trivia game!" << endl;
    }
    else {
        cout << "The trivia game is a tie!" << endl;
    }

    return 0;
}
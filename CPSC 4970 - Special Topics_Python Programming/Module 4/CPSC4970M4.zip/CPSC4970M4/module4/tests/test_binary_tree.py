import unittest
from module4.exercises.binary_tree import BinaryTreeNode, BinaryTree, PreOrderIterator, PostOrderIterator


class TestBinaryTreeIterators(unittest.TestCase):
    def setUp(self):
        # Construct the binary tree as in the main example
        self.n1 = BinaryTreeNode("A")
        self.n2 = BinaryTreeNode("B")
        self.n3 = BinaryTreeNode("C", self.n1, self.n2)
        self.n4 = BinaryTreeNode("D")
        self.n5 = BinaryTreeNode("E", self.n4, self.n3)
        self.n6 = BinaryTreeNode("F", self.n5)
        self.n7 = BinaryTreeNode("G")
        self.n8 = BinaryTreeNode("H", self.n6, self.n7)
        self.tree = BinaryTree(self.n8)

    def test_in_order_traversal(self):
        expected_order = ["D", "E", "A", "C", "B", "F", "H", "G"]
        actual_order = [node.value for node in self.tree]
        self.assertEqual(actual_order, expected_order)

    def test_pre_order_traversal(self):
        iterator = PreOrderIterator(self.tree.root)
        expected_order = ["H", "F", "E", "D", "C", "A", "B", "G"]
        actual_order = [node.value for node in iterator]
        self.assertEqual(actual_order, expected_order)

    def test_post_order_traversal(self):
        iterator = PostOrderIterator(self.tree.root)
        expected_order = ["D", "A", "B", "C", "E", "F", "G", "H"]
        actual_order = [node.value for node in iterator]
        self.assertEqual(actual_order, expected_order)


if __name__ == '__main__':
    unittest.main()
import unittest
from module4.exercises.iterators import OddIterator, Last

# Data variables that can be used and dropped into the tests below for either class.
data_set = []
data1 = [2, 3, 5, 7, 6, 20, 27]
data2 = [2, 4, 6, 8]
data3 = [1, "string", 3.5, 5, 7]
data4 = [1, 2, 3, 4, 5, 6, 7, 8]
data5 = [1, 2, 3]


class TestOddIterator(unittest.TestCase):

    def test_odd_iterator(self):
        expected_result = [3, 5, 7, 27]
        result = [i for i in OddIterator(data1)]
        self.assertEqual(result, expected_result)

    def test_empty_list(self):
        result = [i for i in OddIterator(data_set)]
        self.assertEqual(result, [])

    def test_all_even(self):
        result = [i for i in OddIterator(data2)]
        self.assertEqual(result, [])

    def test_mixed_data(self):
        result = [i for i in OddIterator(data3) if isinstance(i, int)]
        expected_result = [1, 5, 7]
        self.assertEqual(result, expected_result)


class TestLast(unittest.TestCase):

    def test_last_elements(self):
        expected_result = [6, 7, 8]
        result = [i for i in Last(data4, 3)]
        self.assertEqual(result, expected_result)

    def test_more_than_available(self):
        expected_result = [1, 2, 3]
        result = [i for i in Last(data5, 10)]
        self.assertEqual(result, expected_result)

    def test_negative_count(self):
        result = [i for i in Last(data5, -1)]
        self.assertEqual(result, [])

    def test_count_at_zero(self):
        result = [i for i in Last(data5, 0)]
        self.assertEqual(result, [])

    def test_small_size(self):
        expected_result = [3]
        result = [i for i in Last(data5, 1)]
        self.assertEqual(result, expected_result)


if __name__ == '__main__':
    unittest.main()

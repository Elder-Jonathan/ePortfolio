import unittest
from module4.exercises.generators import Generators


class TestFibonacci(unittest.TestCase):
    def test_fibonacci_first_five(self):
        """Tests the first five Fibonacci numbers."""
        it = Generators.fibonacci()
        results = [next(it) for _ in range(5)]
        self.assertEqual(results, [1, 1, 2, 3, 5])

    def test_fibonacci_first_ten(self):
        """Tests the first ten Fibonacci numbers."""
        it = Generators.fibonacci()
        results = [next(it) for _ in range(10)]
        expected = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
        self.assertEqual(results, expected)

    def test_fibonacci_large_index(self):
        """Tests the Fibonacci number at a large index."""
        it = Generators.fibonacci()
        for _ in range(29):
            next(it)
        result = next(it)
        self.assertEqual(result, 832040)


if __name__ == '__main__':
    unittest.main()
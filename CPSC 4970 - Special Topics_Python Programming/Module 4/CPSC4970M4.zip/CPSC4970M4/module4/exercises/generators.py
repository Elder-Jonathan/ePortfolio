# Jonathan Elder
# CPSC 4970 Module 4

class Generators:
    @staticmethod
    def fibonacci():
        """Generates the Fibonacci sequence while starting at
        index 1, 1."""
        a, b = 1, 1
        while True:
            yield a
            a, b = b, a + b




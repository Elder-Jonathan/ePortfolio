# Jonathan Elder
# CPSC 4970 Module 4

class OddIterator:
    def __init__(self, it):
        self.it = iter(it)

    def __iter__(self):
        return self

    def __next__(self):
        while True:
            value = next(self.it)
            if isinstance(value, int) and value % 2 != 0:
                return value


class Last:
    def __init__(self, it, count):
        self.items = list(it)
        self.count = count
        self.index = max(0, len(self.items) - count)

    def __iter__(self):
        return self

    def __next__(self):
        if self.index < len(self.items):
            result = self.items[self.index]
            self.index += 1
            return result
        else:
            raise StopIteration



class BinaryTreeNode:
    def __init__(self, value, left_child=None, right_child=None):
        self.value = value
        self.parent = None
        self._left_child = left_child
        self._right_child = right_child
        if left_child:
            left_child.parent = self
        if right_child:
            right_child.parent = self

    @property
    def left_child(self):
        return self._left_child

    @property
    def right_child(self):
        return self._right_child


class BinaryTree:
    def __init__(self, root=None):
        self.root = root

    @property
    def root(self):
        return self._root

    @root.setter
    def root(self, r):
        self._root = r

    def __iter__(self):
        return InOrderIterator(self.root)


class PreOrderIterator:
    def __init__(self, root):
        self.stack = []
        if root:
            self.stack.append(root)

    def __next__(self):
        if not self.stack:
            raise StopIteration
        current = self.stack.pop()
        if current.right_child:
            self.stack.append(current.right_child)
        if current.left_child:
            self.stack.append(current.left_child)
        return current

    def __iter__(self):
        return self


class InOrderIterator:
    def __init__(self, root):
        self.stack = []
        self.current = root

    def __next__(self):
        while self.current or self.stack:
            while self.current:
                self.stack.append(self.current)
                self.current = self.current.left_child
            self.current = self.stack.pop()
            result = self.current
            self.current = self.current.right_child
            return result
        raise StopIteration

    def __iter__(self):
        return self


class PostOrderIterator:
    def __init__(self, root):
        self.stack = []
        self.last_node_visited = None
        self.current = root

    def __next__(self):
        while self.stack or self.current:
            if self.current:
                self.stack.append(self.current)
                self.current = self.current.left_child
            else:
                peek_node = self.stack[-1]
                if peek_node.right_child and self.last_node_visited != peek_node.right_child:
                    self.current = peek_node.right_child
                else:
                    self.stack.pop()
                    self.last_node_visited = peek_node
                    return peek_node
        raise StopIteration

    def __iter__(self):
        return self


# sample usage
if __name__ == '__main__':
    n1 = BinaryTreeNode("A")
    n2 = BinaryTreeNode("B")
    n3 = BinaryTreeNode("C", n1, n2)
    n4 = BinaryTreeNode("D")
    n5 = BinaryTreeNode("E", n4, n3)
    n6 = BinaryTreeNode("F", n5)
    n7 = BinaryTreeNode("G")
    n8 = BinaryTreeNode("H", n6, n7)
    tree = BinaryTree(n8)

    # In-order traversal using for-loop
    for node in tree:
        print(node.value)
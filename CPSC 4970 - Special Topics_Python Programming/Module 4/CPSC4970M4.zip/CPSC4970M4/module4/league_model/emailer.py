# Jonathan Elder
# CPSC 4970 Module 4

class Emailer:
    """A singleton class for sending emails."""

    _sole_instance = None
    sender_address = ""

    def __new__(cls, *args, **kwargs):
        """Ensure only one instance is created."""
        if not cls._sole_instance:
            cls._sole_instance = super(Emailer, cls).__new__(cls)
        return cls._sole_instance

    @classmethod
    def configure(cls, sender_address):
        """Configure the sender address for the emailer."""
        cls.sender_address = sender_address

    @classmethod
    def instance(cls):
        """Return the sole instance of the Emailer."""
        if not cls._sole_instance:
            cls._sole_instance = cls()
        return cls._sole_instance

    def send_plain_email(self, recipients, subject, message):
        """Simulate sending an email to a list of recipients."""
        for recipient in recipients:
            print(f"Sending mail to: {recipient} with subject '{subject}' and message '{message}'.")
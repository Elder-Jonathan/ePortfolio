# Jonathan Elder
# CPSC 4970 Module 3

from identified_object import IdentifiedObject


class League(IdentifiedObject):
    """Represents a league, containing teams and competitions."""

    def __init__(self, oid, name):
        """Initializes a new League with a unique identifier and name."""
        super().__init__(oid)
        self.name = name
        self._teams = []
        self._competitions = []

    @property
    def teams(self):
        """Returns a list of teams participating in the league."""
        return self._teams

    @property
    def competitions(self):
        """Returns a list of competitions within the league."""
        return self._competitions

    def add_team(self, team):
        """Adds a team to the league if not already present."""
        if team not in self._teams:
            self._teams.append(team)

    def remove_team(self, team):
        """Removes a team from the league if present."""
        if team in self._teams:
            self._teams.remove(team)

    def team_named(self, team_name):
        """Returns a team by name, or None if no such team exists."""
        for team in self._teams:
            if team.name == team_name:
                return team
        return None

    def add_competition(self, competition):
        """Adds a competition to the league."""
        self._competitions.append(competition)

    def teams_for_member(self, member):
        """Returns a list of all teams that a given member is part of."""
        return [team for team in self._teams if member in team.members]

    def competitions_for_team(self, team):
        """Returns a list of competitions that a given team is participating in."""
        return [comp for comp in self._competitions if team in comp.teams_competing]

    def competitions_for_member(self, member):
        """Returns a list of competitions in which a given member is participating through their teams."""
        competitions = []
        for comp in self._competitions:
            for team in comp.teams_competing:
                if member in team.members:
                    competitions.append(comp)
                    break  # Ensure a competition is added only once
        return competitions

    def __str__(self):
        """Returns a string formatted for the league, including its name, number of teams, and competitions."""
        return f"League Name: {self.name}, {len(self._teams)} teams, {len(self._competitions)} competitions"

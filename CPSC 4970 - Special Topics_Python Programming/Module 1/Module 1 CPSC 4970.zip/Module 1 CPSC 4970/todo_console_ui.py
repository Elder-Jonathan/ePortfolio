import datetime

# Initialize the todo_list to an empty array.
todo_list = []


# This function will simply produce the main menu.
def main_menu():
    print("\nMain menu:")
    print("1) List ALL todo items")
    print("2) List all incomplete todo items")
    print("3) List incomplete todo items due today")
    print("4) Add a todo item")
    print("5) Complete a todo item")
    print("6) Quit")


# This function will return simply return a formatted datetime.datetime object to a string.
def current_date(date_string):
    return datetime.datetime.strptime(date_string, '%Y-%m-%d')


# This function will return a list of the item yet to be done.
def all_items():
    if not todo_list:
        print("\nAll items:\nNo items found.")
    else:
        print("\nAll items:")
        for index, (completed, description, due) in enumerate(todo_list):
            status = "Completed" if completed else "Incomplete"
            print(f"{index + 1}. {description} - {due.strftime('%Y-%m-%d')} [{status}]")


# This function will show all the to do items that have not been completed.
def incomplete_items():
    print("\nIncomplete items:")
    for index, (completed, description, due) in enumerate(todo_list):
        if not completed:
            print(f"{index + 1}. {description} - {due.strftime('%Y-%m-%d')}")


# This function will only return the "to do" items that will be due today.
def incomplete_items_due_today():
    today = datetime.datetime.now().date()
    print("\nIncomplete items due today:")
    for index, (completed, description, due) in enumerate(todo_list):
        if not completed and due.date() == today:
            print(f"{index + 1}. {description} - {due.strftime('%Y-%m-%d')}")


# This function will add an item to the to do list.
def add_todo_item():
    description = input("Enter description: ")
    due = input("Enter due date (YYYY-MM-DD): ")
    todo_list.append((False, description, current_date(due)))
    print("Todo item added.")


# This function will complete a to do item.
def complete_todo_item():
    item_number = int(input("Enter item number to mark as completed: ")) - 1
    if 0 <= item_number < len(todo_list):
        completed, description, due = todo_list[item_number]
        todo_list[item_number] = (True, description, due)
        print("Todo item marked as completed.")
    else:
        print("Invalid item number.")


# This is defining the main method and the command prompt of the main menu.
def main():
    while True:
        main_menu()
        choice = input("Enter your choice> ")

        if choice == '1':
            all_items()
        elif choice == '2':
            incomplete_items()
        elif choice == '3':
            incomplete_items_due_today()
        elif choice == '4':
            add_todo_item()
        elif choice == '5':
            complete_todo_item()
        elif choice == '6':
            print("Bye!")
            break
        else:
            print("Invalid choice, please try again.")


if __name__ == "__main__":
    main()

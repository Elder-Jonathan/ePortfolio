# list_tools.py
# Jonathan Elder
# CPSC 4970 Module 2
def all_even(lst):
    """1. Returns a list of even numbers."""
    return [num for num in lst if num % 2 == 0]

def all_not_multiple(lst, n):
    """1. Returns a list of numbers from lst that are not multiples of n."""
    return [num for num in lst if num % n != 0]

def max_from_2_tuples(tuples):
    if not tuples:
        return None
    return (max([t[0] for t in tuples]), max([t[1] for t in tuples]))

def lower_case_words(sentence):
    """Returns a list of lower case words from a sentence."""
    return [word.lower() for word in sentence.split() if word]

def baby_names(names, last_name):
    """Returns a list of unique names called full_names by combining all possible pairs of distinct names with last_name."""
    full_names = [f"{name1} {name2} {last_name}" for i, name1 in enumerate(names) for j, name2 in enumerate(names) if i != j]
    return full_names
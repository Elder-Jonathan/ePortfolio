"""tic_tac_toe.py game for Module 2."""
# Jonathan Elder
# CPSC 4970 Module 2

def initialize_board():
    """Starts an empty Tic-Tac-Toe game/board."""
    return [[" " for _ in range(3)] for _ in range(3)]


def print_board(board):
    """Prints the current state of the board."""
    print("   1   2   3")
    for idx, row in enumerate(board, start=1):
        print(f"{idx}  {' | '.join(row)}")
        if idx < 3:
            print("  --+---+--")


def get_move(player):
    """Asks whoever the current player is for a move and places either an X or O in the corresponding row, column."""
    valid = False
    while not valid:
        try:
            row, col = map(int, input(f"Enter {player} move (row,column no spaces)> ").split(","))
            if 1 <= row <= 3 and 1 <= col <= 3:
                valid = True
            else:
                print("Invalid move, try again.")
        except (ValueError, TypeError):
            print("Invalid input, try again.")
    return row - 1, col - 1


def is_valid_move(board, row, col):
    """Checks for validity of a move before moving to the next step."""
    return board[row][col] == " "


def make_move(board, row, col, player):
    """Attempts to a move from a player on the board; only returns true if it was a success."""
    if is_valid_move(board, row, col):
        board[row][col] = player
        return True
    else:
        print("Invalid move, try again.")
        return False


def check_win(board, player):
    """Checks if the winning conditions have been met with 3 in a row or not."""
    win_conditions = [
                         [board[i][i] for i in range(3)],  # Diagonal
                         [board[i][2 - i] for i in range(3)],  # Anti-diagonal
                     ] + [row for row in board] + [list(col) for col in zip(*board)]  # Rows and columns

    return any(all(cell == player for cell in condition) for condition in win_conditions)


def check_draw(board):
    """Checks if the game is a draw."""
    return all(board[row][col] != " " for row in range(3) for col in range(3))


def tic_tac_toe():
    """Main Tic-Tac-Toe game flow."""
    board = initialize_board()
    current_player = "X"

    while True:
        print_board(board)
        row, col = get_move(current_player)

        if make_move(board, row, col, current_player):
            if check_win(board, current_player):
                print_board(board)
                print(f"\n{current_player} is the winner!")
                break
            elif check_draw(board):
                print_board(board)
                print("\nThe game is a draw!")
                break

            current_player = "O" if current_player == "X" else "X"
        else:
            continue


1
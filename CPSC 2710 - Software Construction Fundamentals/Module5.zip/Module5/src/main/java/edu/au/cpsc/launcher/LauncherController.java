package edu.au.cpsc.launcher;

public class LauncherController {
    // For future use, this will currently remain empty until further use.
}
package edu.au.cpsc.miscstyle;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Part1Controller {
}

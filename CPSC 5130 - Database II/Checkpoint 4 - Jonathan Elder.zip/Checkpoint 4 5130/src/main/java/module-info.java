module edu.au.cpsc.demo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.sql;

    opens edu.au.cpsc.FinalProjectCPSC5130 to javafx.fxml;
    exports edu.au.cpsc.FinalProjectCPSC5130;
}
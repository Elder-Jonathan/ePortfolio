package edu.au.cpsc.FinalProjectCPSC5130;

import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HospitalController {

    @FXML
    private TableView<Map<String, String>> resultTable;

    @FXML
    private TextField patientSearchField;
    @FXML
    private TextField doctorIdField;

    @FXML
    private TextField patientTreatmentIdField;

    @FXML
    private TextField startDateField;
    @FXML
    private TextField endDateField;
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField patientIdField;


    // Update populateTable method in to handle dynamic column names.
    private void populateTable(List<Map<String, String>> data, List<String> columns) {
        resultTable.getItems().clear();
        resultTable.getColumns().clear();

        for (String colName : columns) {
            TableColumn<Map<String, String>, String> column = new TableColumn<>(colName);
            column.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(colName)));
            resultTable.getColumns().add(column);
        }

        List<Map<String, String>> tableData = data.stream().map(item -> {
            Map<String, String> row = new HashMap<>();
            row.put(columns.get(0), item);
            return row;
        }).collect(Collectors.toList());

        resultTable.setItems(FXCollections.observableArrayList(tableData));
    }

    @FXML
    private void listOccupiedRooms() throws IOException {
        List<String> occupiedRooms = HospitalDatabase.getOccupiedRooms();
        populateTable(occupiedRooms, Arrays.asList("Room Number"));
    }

    @FXML
    private void listUnoccupiedRooms() throws IOException {
        List<String> unoccupiedRooms = HospitalDatabase.getUnoccupiedRooms();
        populateTable(unoccupiedRooms, Arrays.asList("Room Number"));
    }

    @FXML
    private void listAllRooms() throws IOException {
        List<Map<String, String>> rooms = HospitalDatabase.getAllRooms();
        populateTable(rooms, Arrays.asList("Room Number", "Status"));
    }

    @FXML
    private void listAllPatients() throws IOException {
        try {
            List<Map<String, String>> patients = HospitalDatabase.getAllPatients();
            populateTable(patients, Arrays.asList("PatientID", "FirstName", "LastName", "EmergencyContact", "InsurancePolicy"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void listCurrentPatients() throws IOException {
        try {
            List<Map<String, String>> currentPatients = HospitalDatabase.getCurrentPatients();
            populateTable(currentPatients);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void listDischargedPatientsByDate() {
        String startDate = startDateField.getText().trim();
        String endDate = endDateField.getText().trim();

        try {
            List<Map<String, Object>> patients = HospitalDatabase.getDischargedPatients(startDate, endDate);
            populateTable(patients);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void listAdmittedPatientsByDate() {
        String startDate = startDateField.getText().trim();
        String endDate = endDateField.getText().trim();

        try {
            List<Map<String, Object>> patients = HospitalDatabase.getAdmittedPatients(startDate, endDate);
            populateTable(patients);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void searchPatientDetails() {
        String searchTerm = patientSearchField.getText().trim();
        if (!searchTerm.isEmpty()) {
            try {
                List<Map<String, String>> patientDetails = HospitalDatabase.getSearchPatientDetails(searchTerm);
                populateTable(patientDetails);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void listAllDoctors() {
        try {
            List<Map<String, String>> doctors = HospitalDatabase.getAllDoctors();
            populateTable(doctors, Arrays.asList("EmployeeID", "FirstName", "LastName", "JobCategory"));
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void listDoctorsWithCurrentPatients() {
        try {
            List<Map<String, String>> doctors = HospitalDatabase.getDoctorsWithCurrentPatients();
            populateTable(doctors);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    // === Section 3 ===

    @FXML
    private void listDiagnosesByOccurrences() {
        try {
            List<Map<String, String>> diagnoses = HospitalDatabase.getDiagnosesByOccurrences();
            populateTable(diagnoses);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void treatmentOccurrenceStats() {
        try {
            List<Map<String, String>> treatments = HospitalDatabase.getTreatmentOccurrenceStats();
            populateTable(treatments);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void frequentPatientDiagnosisCorrelation() {
        try {
            List<Map<String, String>> correlations = HospitalDatabase.getFrequentPatientDiagnosisCorrelation();
            populateTable(correlations);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void treatmentOrdererAndPatientInfo() {
        String patientTreatmentId = patientTreatmentIdField.getText().trim();
        if (!patientTreatmentId.isEmpty()) {
            try {
                List<Map<String, String>> treatmentInfo = HospitalDatabase.getTreatmentOrdererAndPatientInfo(Integer.parseInt(patientTreatmentId));
                populateTable(treatmentInfo);
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Section 4 -  Employee Information

    @FXML
    private void listAllEmployees() throws IOException {
        try {
            List<Map<String, String>> employees = HospitalDatabase.getAllEmployees();
            populateTable(employees);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void doctorsWithHighAdmissionRatePatients() {
        try {
            List<Map<String, String>> doctors = HospitalDatabase.getDoctorsWithHighAdmissionRatePatients();
            populateTable(doctors);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void doctorSpecificDiagnosisStats() {
        String doctorId = doctorIdField.getText().trim();
        if (!doctorId.isEmpty()) {
            try {
                List<Map<String, String>> diagnosisStats = HospitalDatabase.getDoctorSpecificDiagnosisStats(Integer.parseInt(doctorId));
                populateTable(diagnosisStats);
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void doctorSpecificTreatmentStats() {
        String doctorId = doctorIdField.getText().trim();
        if (!doctorId.isEmpty()) {
            try {
                List<Map<String, String>> treatmentStats = HospitalDatabase.getDoctorSpecificTreatmentStats(Integer.parseInt(doctorId));
                populateTable(treatmentStats);
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void employeesTreatingAllPatients() {
        try {
            List<Map<String, String>> employees = HospitalDatabase.getEmployeesTreatingAllPatients();
            populateTable(employees);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void listAdmittedPatientsByDate() {
        String startDate = startDateField.getText().trim();
        String endDate = endDateField.getText().trim();

        try {
            List<Map<String, Object>> patients = HospitalDatabase.getAdmittedPatients(startDate, endDate);
            populateTable(patients);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

}
